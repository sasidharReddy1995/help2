package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;


public class DemandDraftService implements IDemandDraftService{
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		DemandDraftDAO dao=new DemandDraftDAO();
		int s=dao.addDemandDraftDetails(demandDraft);
		return s;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		DemandDraftDAO dao=new DemandDraftDAO();
		DemandDraft ss	=dao.getDemandDraftDetails(transactionId);
		
		return ss;
	}

}
