package com.capgemini.bank.util;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
	public static Connection getConnectionWithDatabase()
	{
		
		Connection conn=null;
		try
		{
			FileReader fr=new FileReader("resources//jdbc.properties");
			Properties p=new Properties();
			p.load(fr);
		    Class.forName(p.getProperty("driver"));
		   conn=DriverManager.getConnection(p.getProperty("url"),p.getProperty("un"),p.getProperty("password"));
	
		}
		catch(IOException |ClassNotFoundException|SQLException e)
		{
			
			e.printStackTrace();
		}
	
		return conn;
	}
}
