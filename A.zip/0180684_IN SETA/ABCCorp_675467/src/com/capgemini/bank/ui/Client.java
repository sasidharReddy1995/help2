package com.capgemini.bank.ui;

import java.util.Scanner;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.service.DemandDraftService;


public class Client {

	public static void main(String[] args) {
		Scanner scanner=new Scanner(System.in);
		DemandDraftService dds=new DemandDraftService();
		
    do
    {
	System.out.println("1) Enter Demand Draft Details");
	System.out.println("2) Print Demand Draft");
	System.out.println("3) Exit");
	
	int choice=scanner.nextInt();
	switch(choice)
	{
	case 1:
		System.out.println("Enter the Name  of the Customer:");
		String name=scanner.next();
		System.out.println("Enter Customer phone Number:");
		long phno=scanner.nextLong();
		System.out.println("In favor of:");
		String favor=scanner.next();
		System.out.println("Enter Demand draft amount (in Rs):");
		int amount =scanner.nextInt();
		System.out.println("Enter Remarks");
		String remarks=scanner.next();
		
	  DemandDraft dd=new DemandDraft(name, phno, favor, amount, remarks);
		int sa=dds.addDemandDraftDetails(dd);
		System.out.println("Your Demand Draft Request has been successfully Registered along with "+sa);
		break;
	case 2:
		System.out.println("Enter Transaction Id");
		int tId=scanner.nextInt();
        DemandDraft d=dds.getDemandDraftDetails(tId);
          System.out.println("Name of the Bank :XYZ");
          System.out.println("DD Amount:"+d.getAmount());
         System.out.println("DD commission :"+d.getCommission());
        System.out.println("Total Amount :"+d.gettotalAmount());
        System.out.println("Remarks:"+d.getRemarks());
        break;			  
	case 3:  
		System.exit(0);
		 break;
		
   default:
			System.err.println("Enter Valid Option");
	}
    }
    while(true);
	}

}
