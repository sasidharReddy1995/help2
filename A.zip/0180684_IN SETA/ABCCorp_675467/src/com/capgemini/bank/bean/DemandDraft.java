package com.capgemini.bank.bean;

public class DemandDraft {
String name;
long phno;
String favor;
int amount;
String remarks;
int total;
int commission;
public DemandDraft()
{
	
}

public DemandDraft(String name,long phno,String favor,int amount,String remarks) 
{
	
	this.name = name;
	this.phno = phno;
	this.favor = favor;
	this.amount = amount;
	this.remarks = remarks;
}
public String getName() {
	return name;
}


public long getPhno() {
	return phno;
}


public String getFavor() {
	return favor;
}

public int getAmount() {
	return amount;
}

public String getRemarks() {
	return remarks;
}

public void setName(String name) {
	this.name = name;
}
public void setPhno(long phno) {
	this.phno = phno;
}
public void setFavor(String favor) {
	this.favor = favor;
}
public void setAmount(int amount) {
	this.amount = amount;
}
public void setRemarks(String remarks) {
	this.remarks = remarks;
}
public void setCommission(int mm)
{
	this.commission=mm;
}

public void settotalAmount(int total)
{
	this.total=total;
}
public int getCommission()
{
	
	return commission;
}

public int gettotalAmount()
{	
	return total;
}



}


