package com.capgemini.bank.dao;

import static org.junit.Assert.*;

import org.junit.Test;

public class DemandDraftDAOTest {

	@Test
	public void test() {
		DemandDraftDAO d=new DemandDraftDAO();
	
	}

}
