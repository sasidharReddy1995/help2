package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.query.QueryMapper;
import com.capgemini.bank.util.DBConnection;

public class DemandDraftDAO implements IDemandDraftDAO{
Connection conn;


	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) {
		int gg=0;
		try{
		conn=DBConnection.getConnectionWithDatabase();
		PreparedStatement ps=conn.prepareStatement(QueryMapper.INSERT);
		Date dat=new Date();
		long time=dat.getTime();
		java.sql.Date date=new java.sql.Date(time);
		Statement s=conn.createStatement();
        ResultSet f=s.executeQuery("Select Transaction_Id_Seq.nextval from dual");
       
        int commission=0;
        while(f.next())
        {
        gg=	f.getInt(1);
        }
        if(demandDraft.getAmount()<5000)
        {
        	commission=10;
        }
        if(demandDraft.getAmount()>=5000 && demandDraft.getAmount()<=10000)
        {
        	commission=41;
        }
        if(demandDraft.getAmount()>=10001 && demandDraft.getAmount()<=100000)
        {;
        	commission=51;
        }
        if(demandDraft.getAmount()>=100001 && demandDraft.getAmount()<=500000)
        {
        	commission=306;
        }
        ps.setInt(1, gg);
		ps.setString(2,demandDraft.getName());
		ps.setString(3,demandDraft.getFavor());
		ps.setLong(4,demandDraft.getPhno());
		ps.setDate(5,date);
		ps.setInt(6,demandDraft.getAmount());
		ps.setInt(7,commission);
		ps.setString(8,demandDraft.getRemarks());
		}
		catch(SQLException e)
		{
			
		}
		return gg;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) {
		DemandDraft demandd=new DemandDraft();
		try{
			
			Statement s=conn.createStatement();
		    String fc="select * from demand_draft where transaction_id="+transactionId;
		
		    ResultSet dd= s.executeQuery(fc);
		    
		   
			while(dd.next()){
			int d=dd.getInt(6);
			 demandd.setAmount(d);
			 demandd.setRemarks(dd.getString(8));
			 int comm=dd.getInt(8);
			 int total=d+comm;
			 demandd.setCommission(comm);
			
			 demandd.settotalAmount(total);
			}	
		}
		catch(SQLException s)
		{
			
		}
		
		return demandd;
	}

}
