package com.capgemini.bank.query;

public interface QueryMapper {
public static final String INSERT="Insert into demand_draft values(?,?,?,?,?,?,?,?)";

}
